import java.util.Scanner;
public class GameHomework
{
    public static void main (String[] args)
    {
        int x = 2;
        int y = 2;
        boolean stop = true;
        Scanner keyboardScanner = new Scanner(System.in);
        while(stop)
        {
            for (int i = 0; i < 5 ; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    if (j == x && i == y)
                    {
                        System.out.print("P ");
                    }
                    else
                    {
                        System.out.print("- ");
                    }
                }
                System.out.print("\n");
            }
            System.out.println("Press W to move up; S to move down, A to move left, D to move right, 1 to stop");
            String move = keyboardScanner.next();
            if(move.equals("W") || move.equals("w"))
            {
                y = y - 1;
                if (y < 0)
                {
                    System.out.println("You cannot go out of bound");
                    y = y + 1;
                }
            }
            else if(move.equals("S") || move.equals("s"))
            {
                y = y + 1;
                if (y >= 5)
                {
                    System.out.println("You cannot go out of bound");
                    y = y - 1;
                }
            }
            else if(move.equals("A") || move.equals("a"))
            {
                x = x - 1;
                if (x < 0)
                {
                    System.out.println("You cannot go out of bound");
                    x = x + 1;
                }
            }
            else if(move.equals("D") || move.equals("d"))
            {
                x = x + 1;
                if (x >= 5)
                {
                    System.out.println("You cannot go out of bound");
                    x = x - 1;
                }
            }
            else if(move.equals("1"))
            {
                stop = false;
                System.out.println("You have successfully stopped");
            }
            else if(x < 0 || y < 0)
            {
                System.out.println("You cannot go out of bound");
            }
            else if(!move.equals("W") && !move.equals("w") && !move.equals("S") && !move.equals("s") && !move.equals("A") && !move.equals("a") && !move.equals("D") && !move.equals("d") && !move.equals("1"))
            {
                System.out.println("You have entered an invalid input");
            }
        }
    }
}
